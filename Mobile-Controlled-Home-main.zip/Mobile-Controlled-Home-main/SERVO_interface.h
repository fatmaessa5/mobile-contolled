#ifndef SERVO_INTERFACE_H
#define SERVO_INTERFACE_H

void HSERVO_voidTurnRight(void);

void HSERVO_voidTurnLeft(void);

void HSERVO_voidLookForward(void);

void HSERVO_voidInit(void);


#endif
