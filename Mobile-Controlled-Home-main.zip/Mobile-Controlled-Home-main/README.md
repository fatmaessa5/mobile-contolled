# Mobile-Controlled-Home
The project revolves around a controlled home setup facilitated by a mobile applicatin. Users can manipulate various functinalitis such as opening/closing doors, room light. While the system has the capability to control other home devices, for the purpose of simulatin, this functinality is demonstrated solely through LED lights.
