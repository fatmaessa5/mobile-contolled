#ifndef BUZZER_INTERFACE_H_
#define BUZZER_INTERFACE_H_


void BUZZER_voidInit();
void BUZZER_voidTurnON();
void BUZZER_voidTurnOFF();


#endif
