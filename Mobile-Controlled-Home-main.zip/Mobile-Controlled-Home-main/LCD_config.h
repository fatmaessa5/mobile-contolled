#ifndef LCD_CONFIG_H
#define LCD_CONFIG_H

#define LCD_DATA_PORT  PORTC
#define LCD_CTRL_PORT  PORTB
#define LCD_RS_PIN     PIN0
#define LCD_RW_PIN     PIN1
#define LCD_EN_PIN     PIN2
#define LCD_MODE       FOUR_BIT
/*
 * FOUR_BIT
 * EIGHT_BIT
 */

#endif
