#ifndef BUZZER_CONFIG_H_
#define BUZZER_CONFIG_H_



#define BUZZER_PORT			PORTA
#define BUZZER_PIN			PIN7



#endif
