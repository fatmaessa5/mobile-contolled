#ifndef LCD_PRIVATE_H
#define LCD_PRIVATE_H

#define DDRAM_OFFSET 0X40


#endif
